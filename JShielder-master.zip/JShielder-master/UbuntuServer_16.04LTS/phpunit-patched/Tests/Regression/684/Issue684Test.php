<?php
class Foo_Bar_Issue684Test extends PHPUnit_Framework_TestCase
{
}
