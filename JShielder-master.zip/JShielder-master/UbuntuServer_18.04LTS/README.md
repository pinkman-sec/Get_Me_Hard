JShielder_UbuntuServer_18.04LTS
=========================

JShielder For Ubuntu Server 18.04LTS

See JShielder README
